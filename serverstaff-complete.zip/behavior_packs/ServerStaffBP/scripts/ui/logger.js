
// Este arquivo foi movido para ../utils.js
// Mantido vazio para prevenir erros de cache se o arquivo não for deletado.
